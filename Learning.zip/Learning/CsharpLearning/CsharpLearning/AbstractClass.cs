﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public abstract class AbstractClass
    {
        private AbstractClass()
        {
            Console.WriteLine("Private Constructor");
        }
        public AbstractClass(int i)
        {
            Console.WriteLine("Parameterize Constructor");
        }
    }

    public class NonAbstractClass : AbstractClass
    {
        public NonAbstractClass(int i):base(i)
        {
            Console.WriteLine("Parameterize Constructor in NonAbstract Class");
        }
    }
}
