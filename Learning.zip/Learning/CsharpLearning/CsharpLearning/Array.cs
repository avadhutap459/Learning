﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class Array
    {
        public int[] SingleArr = new int[5];

        public int[,] MuliArr = new int[5,3];

        public int[][] JagArr = new int[3][];

        public Array()
        {
            SingleArr = new int[5] { 1, 2, 3, 4, 5 };

            MuliArr = new int[5, 3]
            {
                {1,2,3 },
                {2,3,4},
                {3,4,5},
                {4,5,6},
                {5,6,7}
            };

            JagArr[0] = new int[4] {1,2,3,4};

            JagArr[1] = new int[2] { 5, 8 };

            JagArr[2] = new int[8] { 7, 9, 8, 3, 25, 5, 8, 5};

        }
    }
}
