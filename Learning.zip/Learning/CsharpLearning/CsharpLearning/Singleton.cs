﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class Singleton
    {
        private Singleton()
        {
            counter++;
        }
        private static Singleton Instance = null;
        private static int counter = 0;
        public static Singleton _Instance
        {
            get 
            { 
                if(Instance == null)
                    Instance = new Singleton();

                return Instance;
            }
        }
        public void PrintDetails(string message)
        {
            Console.WriteLine(message);
        }

    }


    public class ClsSingleton
    {
        private static int counter = 0;
        private static ClsSingleton instance = null;
        public static ClsSingleton GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new ClsSingleton();
                return instance;
            }
        }
        public ClsSingleton()
        {
            counter++;
            Console.WriteLine("Counter Value " + counter.ToString());
        }
        public void PrintDetails(string message)
        {
            Console.WriteLine(message);
        }
        
    }

  

    public class SingleToneClass
    {
        private SingleToneClass()
        {
            Console.WriteLine("Private Constructor");
        }

        private static SingleToneClass Instance { get; set; }

        public static SingleToneClass _Instance
        {
            get
            {
                if (Instance != null)
                    Instance = new SingleToneClass();
                return Instance;
            }
        }
    }

}
