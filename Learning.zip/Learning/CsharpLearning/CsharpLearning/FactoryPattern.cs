﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    internal class FactoryPattern
    {
    }


    public interface ICard
    {
        void CreditCard();
        void DebitCard();
    }
    public class PersonalBank : ICard
    {
        public void CreditCard()
        {
            Console.WriteLine("Icici bank credit card");
        }

        public void DebitCard()
        {
            Console.WriteLine("Icici bank debit card");
        }
    }
    public class HousingBank : ICard
    {
        public void CreditCard()
        {
            Console.WriteLine("Hdfc bank credit card");
        }

        public void DebitCard()
        {
            Console.WriteLine("Hdfc bank debit card");
        }
    }

    public interface TempCardFactory
    {
        ICard CreateCardDetail();
    }

    public class IciciBank : TempCardFactory
    {
        public ICard CreateCardDetail()
        {
            return new PersonalBank();
        }
    }

    public class HdfcBank : TempCardFactory
    {
        public ICard CreateCardDetail()
        {
            return new HousingBank();
        }
    }

    public class BankClient
    {
        ICard _carddetails;

        public BankClient(TempCardFactory CardFactory)
        {
            _carddetails = CardFactory.CreateCardDetail();
        }

        public void PrintCreditCard()
        {
            _carddetails.CreditCard();
        }

        public void PrintDebitCard()
        {
            _carddetails.DebitCard();
        }
    }
}
