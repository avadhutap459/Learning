﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    internal class SentMailFactory
    {
    }

    public interface ISentMail
    {
        byte[] ConvertHTMLToByte(string _text);
        void SentMail(byte[] byteArr);
    }

    public class SentMail : ISentMail
    {
        public byte[] ConvertHTMLToByte(string _text)
        {
            throw new NotImplementedException();
        }

        void ISentMail.SentMail(byte[] byteArr)
        {
            throw new NotImplementedException();
        }
    }

    public interface IMailTriggerFactory
    {
        ISentMail CreateMail();
    }

    public class BOIBank : IMailTriggerFactory
    {
        public ISentMail CreateMail()
        {
            return new SentMail();
        }
    }

    public class UBIBank : IMailTriggerFactory
    {
        public ISentMail CreateMail()
        {
            return new SentMail();
        }
    }

    public class MailClient
    {
        ISentMail SentMail;

        public MailClient(IMailTriggerFactory MailFactory)
        {
            SentMail = MailFactory.CreateMail();
        }

        public byte[] GenerateByteToHtml(string _txt)
        {
            return SentMail.ConvertHTMLToByte(_txt);
        }

        public void MailTrigger(byte[] byArr)
        {
            SentMail.SentMail(byArr);
        }

    }
}
