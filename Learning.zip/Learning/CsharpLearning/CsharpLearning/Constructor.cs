﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class Constructor
    {
        static Constructor()
        {
            Console.WriteLine("Static Constructor");
        }
        private Constructor()
        {
            Console.WriteLine("Private Constructor");
        }
        public Constructor(string name)
        {
            Console.WriteLine(name);
        }
    }



    public class PrivateConstructor
    {
        private PrivateConstructor()
        {
            Console.WriteLine("Private Constructor");
        }
    }

    public class Class_1
    {
        public Class_1()
        {
            Console.WriteLine("Default Class_1 constructor");
        }
        static Class_1()
        {
            Console.WriteLine("Static Class_1 constructor");
        }
        //public Class_1(int i)
        //{
        //    Console.WriteLine("Paramterize Class_1 constructor");
        //}
    }

    public class Class_2 : Class_1
    {
        public Class_2() : base()
        {
            Console.WriteLine("Default Class_2 constructor");
        }
        public Class_2(int i) 
        {
            Console.WriteLine("Paramterize Class_2 constructor");
        }
    }

}
