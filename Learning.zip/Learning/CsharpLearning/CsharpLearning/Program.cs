﻿using System;
using System.Collections;
using static CsharpLearning.StaticClass;

namespace CsharpLearning
{
    internal class Program 
    {
        static void Main(string[] args)
        {

            Property objProperty = new Property();

            objProperty.ReturnProperty();

            Class_2 obj_2 = new Class_2();


            MoreGenericParam<string,int> param = new MoreGenericParam<string,int>();


            IMailTriggerFactory MailFactory = new BOIBank();

            MailClient _mailClient = new MailClient(MailFactory);

            string Html = string.Empty;

            byte[] byteArr =  _mailClient.GenerateByteToHtml(Html);

            _mailClient.MailTrigger(byteArr);





            MailFactory = new UBIBank();

            _mailClient = new MailClient(MailFactory);

             byteArr = _mailClient.GenerateByteToHtml(Html);

            _mailClient.MailTrigger(byteArr);







            TempCardFactory IcicFactory = new IciciBank();

            BankClient _bankClient = new BankClient(IcicFactory);

            _bankClient.PrintCreditCard();
            _bankClient.PrintDebitCard();


            TempCardFactory HdfcFactory = new HdfcBank();

            _bankClient = new BankClient(HdfcFactory);
            _bankClient.PrintCreditCard();
            _bankClient.PrintDebitCard();


            _PublicCls_OverriderProperty Obj_VPro = new _PublicCls_OverriderProperty();

            string Teamp = Obj_VPro.VirtualProperty;

            _PublicCls_PrivatePro _PublicCls_PrivatePro = new _PublicCls_PrivatePro();

            string Temp_ = _PublicCls_PrivatePro._publicPro;

            _OverrideAbstractClass _OverrideAbstractClass = new _OverrideAbstractClass();


            //NonAbstractClass objNAb = new NonAbstractClass(1);

            // PrivateConstructor ObjPrCon = new PrivateConstructor();

            ClsSingleton Single_1 = ClsSingleton.GetInstance;
            ClsSingleton Single_2 = ClsSingleton.GetInstance;

            NonStaticClass ObjNStatic = new NonStaticClass();

            ObjNStatic.GetName();

            Singleton fromTeachaer = Singleton._Instance;

            Constructor ObjCon = new Constructor("Parameterize constructor");

            var Con = typeof(Constructor).GetConstructor(System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance, null, new Type[0], null);

            var instance = (Constructor)Con.Invoke(null);

            XmlOperation.CreateXMLUsingString();
            XmlOperation.CreateXMLFile();
            XmlOperation.CreateXMLUsingSetting();

            Property ObjProperty = new Property();

            ObjProperty.ReturnProperty();

            PublicCls_VirtualProperty ObjVirtualProperty = new PublicCls_VirtualProperty();

            Console.WriteLine(ObjVirtualProperty.VirtualProperty);

            PublicCls_OverrideProperty ObjOverrideProperty= new PublicCls_OverrideProperty();

            ObjOverrideProperty.ReturnOverrideProperty();

            InheritAbstractClass ObjInheritAbCls = new InheritAbstractClass();

            Console.WriteLine(ObjInheritAbCls.AbstractMember);
            Console.WriteLine(ObjInheritAbCls.NonAbstractMemberWithBase);


            Array ObjArray = new Array();

            Console.WriteLine(ObjArray.SingleArr.ToString());

            Console.WriteLine(ObjArray.MuliArr.ToString());

            ParamsKey.GetParamData(1, 2, 3, 4, 56, 8, 9,89);

            ArrayList ObjArrayList = new ArrayList();

            ObjArrayList.Add(1);
            ObjArrayList.Add("Avadhut Parab");
            ObjArrayList.Add(4.5);
            ObjArrayList.Add(1.2589752);

            Collection.ReturnArrayListData(ObjArrayList);

            Collection.ReturnList();

            Collection.RetrunDictionary();


            FileCreate.FileCreateUsingFileStream();
            FileCreate.FileReadUsingFileStream();

            FileCreate.FileCreateUsingStreamWriter();
            FileCreate.FileReadUsingStreamWriter();

            GenericClass.GetData<string>("Avadhut");

            Console.WriteLine("Hello World!");
        }
    }
}
