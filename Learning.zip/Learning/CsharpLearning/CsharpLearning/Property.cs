﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class Property : PublicCls_PublicProperty
    {
        PublicCls_PublicProperty ObjPC_PP = new PublicCls_PublicProperty();
        //Property ObjPro= new Property();

        public void ReturnProperty()
        {
            Console.WriteLine(ObjPC_PP.PublicProperty);

            Console.WriteLine(ObjPC_PP.PrivateProperty);

            Console.WriteLine(PublicCls_PublicProperty.StaticProperty);

            Console.WriteLine(ProtectedProperty);

            Console.WriteLine(ObjPC_PP.InternalProperty);
        }
    }
    public class PublicCls_PublicProperty
    {
        public string PublicProperty { get; set; } = "Public Class Inside Public Property";
        private string _PrivateProperty { get; set; } = "Public Class Inside Private Property";

        public string PrivateProperty
        {
            get
            {
                return _PrivateProperty;
            }
        }
        public static string StaticProperty { get; set; } = "Public Class Inside Static Property";
        protected string ProtectedProperty { get; set; } = "Public Class Inside Protected Property";
        internal string InternalProperty { get; set; } = "Public Class Inside Internal Property";

    }

    public class PublicCls_VirtualProperty
    {
        virtual public string VirtualProperty { get; set; } = "Virtual Property";

        public virtual string First { get; set; } = "Adam";

        
    }

    public class PublicCls_OverrideProperty : PublicCls_VirtualProperty
    {
        public override string VirtualProperty { get; set; }

        public override string First { get; set; }

        //public override string First
        //{
        //    get { return base.First; }
        //    set
        //    {
        //        Console.WriteLine($"Child property hit with the value: '{0}'");
        //        base.First = value;
        //    }
        //}


        public PublicCls_OverrideProperty()
        {
            base.First = "Override member with base keyword";
            VirtualProperty = "Override Property";
        }

        public void ReturnOverrideProperty()
        {
            Console.WriteLine(VirtualProperty);
        }
    }

    public abstract class AbstractClass_Member
    {
        public abstract string AbstractMember { get; set; }
        public string NonAbstractMemberWithBase { get; set; }
    }

    public class InheritAbstractClass : AbstractClass_Member
    {
        public override string AbstractMember
        {
            get;set;
        }
        
        public InheritAbstractClass()
        {
            AbstractMember = "Override abstract member";
            base.NonAbstractMemberWithBase = "Override abstract member with base keyword";
        }
    }

    




    public class _PublicCls_VirtualProperty
    {
        public virtual string VirtualProperty { get; set; } = "Print Virtual Property";

        public virtual string _VirtualPro { get; set; } = "Print Virtual Property";
    }

    public class _PublicCls_OverriderProperty : _PublicCls_VirtualProperty
    {
        public override string VirtualProperty 
        {
            get { return base.VirtualProperty; }
            set { base.VirtualProperty = value; }
        }

        public virtual string _VirtualPro { get; set; } = "Print Override Property";
    }


    public class _PublicCls_PrivatePro
    {
        private string _PrivatePro { get; set; }

        public string _publicPro
        {
            get { return _PrivatePro; }
            set { _PrivatePro = value; }
        }
    }


    public abstract class _AbstractClass_AbProperty
    {
        public abstract string AbstractMember { get; set; }

        public string _NonAbstractMember { get; set; } = "Non Abstract Member in abstract class";
    }
    public class _OverrideAbstractClass : _AbstractClass_AbProperty
    {
        public override string AbstractMember { get; set; } = "Override Member";

        public string _NonAbstractMember { get; set; } = "Non Abstract Member in override class";
    }

}
