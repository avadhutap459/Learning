﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    internal class Dictionary
    {
        Dictionary<int, string> dictionary = new Dictionary<int, string>();

        public Dictionary<int,string> AddElement()
        {
            dictionary.Add(0, "Avadhut");
            dictionary.Add(1, "Anant");
            dictionary.Add(2, "Parab");

            return dictionary;
        }
    }
}
