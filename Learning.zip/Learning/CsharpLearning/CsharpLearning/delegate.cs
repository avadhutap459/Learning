﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class @delegate
    {

        public  delegate void Add();

        Add dAdd = delegate ()
        {
            Console.WriteLine("Add delegate funcation call");
        };
    }
}
