﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using System.IO;
using System.Xml;

namespace CsharpLearning
{
    public class XmlOperation
    {
        


		public static void CreateXMLUsingString()
        {
			string XML = @"<object>
								<name>Sphere</name>
								<material>Steel</material>
								<device Id='01'>
									<model>Model 1</model>
									<color>Red</color>
								</device>
								<device Id='02'>
									<model>Model 2</model>
									<color>Blue</color>
								</device>
							</object>";

			XmlDocument xdoc = new XmlDocument();
			xdoc.LoadXml(XML);
			xdoc.Save(@"D:\xmlDoc.xml");

			XDocument doc = XDocument.Load(@"D:\xmlDoc.xml");
			foreach (var itemElement in doc.Elements("object"))
			{
				Console.WriteLine(itemElement.Element("name").Value);
				Console.WriteLine(itemElement.Element("material").Value);
				foreach (var device in itemElement.Elements("device"))
				{
					Console.WriteLine(device.Element("model").Value);
					Console.WriteLine(device.Element("color").Value);
				}
			}


		}


		public static void CreateXMLFile()
        {
			FileStream FStream = new FileStream(@"D:\XmlDocument.xml", FileMode.OpenOrCreate);
			using (XmlWriter writer = XmlWriter.Create(FStream))
			{
				writer.WriteStartElement("book");
				writer.WriteElementString("title", "Graphics Programming using GDI+");
				writer.WriteElementString("author", "Mahesh Chand");
				writer.WriteElementString("publisher", "Addison-Wesley");
				writer.WriteElementString("price", "64.95");
				writer.WriteEndElement();
				writer.Flush();
			}
        }

		public static void CreateXMLUsingSetting()
        {
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.Indent = true;
			settings.IndentChars = ("    ");
			settings.CloseOutput = true;
			settings.OmitXmlDeclaration = true;

			FileStream FStream = new FileStream(@"D:\XmlDocument1.xml", FileMode.OpenOrCreate);
			using (XmlWriter writer = XmlWriter.Create(FStream, settings))
			{
				writer.WriteStartElement("book");
				writer.WriteElementString("title", "Graphics Programming using GDI+");
				writer.WriteElementString("author", "Mahesh Chand");
				writer.WriteElementString("publisher", "Addison-Wesley");
				writer.WriteElementString("price", "64.95");
				writer.WriteEndElement();
				writer.Flush();
			}
		}

	}
}
