﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;


namespace CsharpLearning
{
    public class FileCreate
    {
        public static void FileCreateUsingFileStream()
        {
            FileStream F = new FileStream(@"D:\Demo.txt", FileMode.OpenOrCreate);

            F.WriteByte(58);
            F.Close();
        }

        public static void FileReadUsingFileStream()
        {
            FileStream F = new FileStream(@"D:\Demo.txt", FileMode.OpenOrCreate);

            int i = 0;

            while(( i = F.ReadByte()) != -1)
            {
                Console.WriteLine((char)i);
            }

            F.WriteByte(58);
            F.Close();
        }

        public static void FileCreateUsingStreamWriter()
        {
            FileStream F = new FileStream(@"D:\StreamWriter.txt", FileMode.OpenOrCreate);

            StreamWriter SW = new StreamWriter(F);

            SW.Write("Name : Avadhut Parab");
            SW.Write("\n");
            SW.Write("Department : Computer Engineer");
            SW.Close();
            F.Close();
        }
        public static void FileReadUsingStreamWriter()
        {
            FileStream F = new FileStream(@"D:\StreamWriter.txt", FileMode.Open);

            StreamReader SR = new StreamReader(F);

            Console.WriteLine(SR.ReadToEnd());


            SR.Close();
            F.Close();
        }

        public void FileCreateUsingTextWriter()
        {

            TextWriter TW = new StreamWriter(@"D:\Textwriter.txt");

            TW.WriteLine("Name : Avadhut Parab");
            TW.WriteLine("\n");
            TW.WriteLine("Department : Computer Engineer");
        }

        public static void FileReadUsingTextReader()
        {
            TextReader TR = new StreamReader(@"D:\Textwriter.txt");

            Console.WriteLine(TR.ReadToEnd());
        }

        public void FileCreateUsingBinaryWriter()
        {
            using (BinaryWriter bw = new BinaryWriter(File.Open(
             @"D:\BinaryWriter.txt", FileMode.Create)))
            {
                //writes the data to the stream
                bw.Write(25);
                bw.Write(23.98);
                bw.Write('c');
                bw.Write("GeeksForGeeks");
                bw.Write(true);
                Console.WriteLine("Successfully Written");
                Console.ReadLine();
            }
        }

        public void FileCreateUsingBinaryReader()
        {
            using (BinaryReader BR = new BinaryReader(File.Open(
             @"D:\BinaryWriter.txt", FileMode.Open)))
            {
                Console.WriteLine(BR.Read());
            }
        }

        public void FileCreateUsingFileInfo()
        {
            FileInfo Finfo = new FileInfo(@"D:\FileInfo.txt");

            StreamWriter SW = Finfo.CreateText();

            SW.WriteLine("Name : AVadhut Parab");

            SW.Close();
            
        }

        public void FileReadUsingFileInfo()
        {
            FileInfo Finfo = new FileInfo(@"D:\FileInfo.txt");

            StreamReader SR = Finfo.OpenText();
            string data = string.Empty;

            while((data = SR.ReadLine()) != null)
            {
                Console.WriteLine(data);
            }

        }

        public void FileCreateUsingBinarySeralization()
        {
            FileStream FStream = new FileStream(@"D:\BinarySeralize.txt",FileMode.OpenOrCreate);

            BinaryFormatter BF = new BinaryFormatter();

            dynamic Obj = new
            {
                id = 101,
                name = "Avadhut Parab"
            };

            BF.Serialize(FStream, Obj);

            FStream.Close();


        }

        public void FileReadUsingBinarySeralization()
        {
            FileStream FStream = new FileStream(@"D:\BinarySeralize.txt", FileMode.Open);

            BinaryFormatter BF = new BinaryFormatter();

            dynamic Obj = BF.Deserialize(FStream);

            Console.WriteLine(Obj.name);
        }


    }
}
