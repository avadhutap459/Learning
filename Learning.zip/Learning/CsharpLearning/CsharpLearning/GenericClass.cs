﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class GenericClass
    {
        public static T GetData<T>(T name)
        {
            T result = default(T);

            return result;
        }
    }


    public class MoreGenericParam<T,C>
    {
        public T Name { get; set; }

        public C NameValue { get; set; }
        public static void Return(T ReturnT,C ReturnC)
        {
            Console.WriteLine(ReturnC);

            Console.WriteLine(ReturnT);
        }
    }
}
