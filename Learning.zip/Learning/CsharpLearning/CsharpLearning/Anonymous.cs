﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class Anonymous
    {
        public delegate void Add();

        Add fun = delegate ()
         {
             Console.WriteLine("Anonymous function call");
         };



        public void CallAnonymousFunction()
        {
            fun();
        }

        public void CreateAnonymousType()
        {
            var Employee = new { Id = 1, Name = "Avadhut" };

            var ListOfEmployee = new[]
            {
                new { Id = 1, Name = "Avadhut" },
                new { Id = 2, Name = "Anant" },
                new { Id = 3, Name = "Parab" }
            };
        }

    }
}
