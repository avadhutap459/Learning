﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CsharpLearning
{
    public class Collection
    {
        public static void ReturnArrayListData(ArrayList ObjArray)
        {
            foreach(var Arr in ObjArray)
            {
                Console.WriteLine(Arr.ToString());
            }
        }

        public static void ReturnCollectionList()
        {
           
        }

        public static void ReturnList()
        {
            List<int> lst = new List<int>();
            lst.Add(5);
            lst.Add(1);
            lst.Add(4);
            lst.Add(6);

            Console.WriteLine(lst.Count);

            lst.Sort();

            foreach(int i in lst)
            {
                Console.WriteLine(i);
            }

            lst.Clear();
        }

        public static void RetrunDictionary()
        {
            Dictionary<int, string> dic = new Dictionary<int, string>();

            dic.Add(1, "Avadhut");
            dic.Add(2, "Anant");
            dic.Add(3, "Parab");


            dic.OrderBy(x => x.Key).ToList();

            dic.Select(x => x.Value).ToList();
        }
    }
}
