﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    internal class AbstractFactoryPattern
    {
    }

    public abstract class Card
    {
        public abstract string CardType { get; set; }
        public abstract int CardLimit { get; set; }
    }

    public class CreditCard : Card
    {
        public CreditCard()
        {
            CardType = "Credit Card";
            CardLimit = 50000;
        }
        public override string CardType
        {
            get { return CardType; }
            set { CardType = value; }
        }
        public override int CardLimit
        {
            get { return CardLimit; }
            set { CardLimit = value; }
        }
    }

    public class DebitCard : Card
    {
        public DebitCard()
        {
            CardType = "Debit Card";
            CardLimit = 500000;
        }
        public override string CardType 
        { 
            get { return CardType; }
            set { CardType = value; }
        }
        public override int CardLimit
        {
            get { return CardLimit; }
            set { CardLimit = value; }
        }
    }

    public abstract class CardFactory
    {
        public abstract Card CreateCard();
    }

    public class ICICIBank : CardFactory
    {
        public override Card CreateCard()
        {
            return new CreditCard();
        }
    }
}
