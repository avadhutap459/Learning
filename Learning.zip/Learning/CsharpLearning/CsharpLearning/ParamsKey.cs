﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class ParamsKey
    {
        public static void GetParamData(params int[] val)
        {
            foreach(int i in val)
            {
                Console.WriteLine(i);
            }
        }
    }
}
