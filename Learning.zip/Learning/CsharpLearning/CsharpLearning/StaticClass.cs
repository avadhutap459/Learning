﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    public class StaticClass
    {
        interface IName
        {
            public void GetName();
        }

        public class NonStaticClass : IName
        {
            public void GetName()
            {
                Console.WriteLine("Avadhut Parab");
            }
        }
    }
}
