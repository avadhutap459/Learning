﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpLearning
{
    internal class LockNMonitor
    {

        public void _MethodLock()
        {
            string name = "My name is Avadhut";
            Object ObjLock = new Object();
            try
            {
                lock (ObjLock)
                {
                    foreach (char c in name.ToCharArray())
                    {
                        Console.WriteLine(c);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            
        }


    }
}
