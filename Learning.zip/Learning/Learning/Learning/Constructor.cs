﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Learning
{
    public class Constructor
    {
       public int i { get; set; }
        public int j { get; set; }


    }
}
